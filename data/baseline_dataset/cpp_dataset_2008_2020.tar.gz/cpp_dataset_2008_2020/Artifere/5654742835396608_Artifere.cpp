#include <iostream>
 #include <cstdio>
 #include <map>
 
 using namespace std;
 
 int main()
 {
     freopen("t.in", "r", stdin);
     freopen("t.out", "w", stdout);
 
 
     int nbT;
     cin >> nbT;
 
 
     int new1, new2;
     for (int t = 1; t <= nbT; t++)
     {
         int taille, nbGens;
         cin >> taille >> nbGens;
         map<int,int> gaps;
         gaps[taille] = 1;
 
         for (int i = 0; i < nbGens; i++)
         {
             auto itCurTaille = gaps.end();
             itCurTaille--;
             const int curTaille = itCurTaille->first;
             if (itCurTaille->second == 1)
                 gaps.erase(itCurTaille);
             else
                 itCurTaille->second -=1;
 
             //std::cerr << curTaille << "aaaaaa" << taille << std::endl;
 
             if (curTaille%2)
             {
                 new1 = curTaille/2;
                 new2 = curTaille/2;
             }
             else
             {
                 new1 = max(0,curTaille/2-1);
                 new2 = curTaille/2;
             }
 
             auto it1 = gaps.find(new1);
             if (it1 == gaps.end())
                 gaps[new1] = 1;
             else
                 it1->second += 1;
 
             auto it2 = gaps.find(new2);
             if (it2 == gaps.end())
                 gaps[new2] = 1;
             else
                 it2->second += 1;
         }
 
 
         std::cout << "Case #" << t << ": " << max(new1, new2) << ' ' << min(new1, new2) << '\n';
 
         //break;
     }
     return 0;
 }
