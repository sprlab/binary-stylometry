#include<iostream>
 #include<string>
 #include<vector>
 #include<sstream>
 #include<cmath>
 #include<algorithm>
 #include<numeric>
 #include<map>
 #include<set>
 #include<queue>
 #include<cstring>
 #include<cstdio>
 using namespace std;
 
 int c[1001];
 int n;
 
 int f(){
     int maxi=0;
     for(int i=0;i<n;i++)maxi=max(maxi,c[i]);
     
     if(maxi<=2)return maxi;
     
     for(int i=0;i<n;i++)
         if(maxi==c[i]){
             c[n]=c[i]/2;
             c[i]=c[i]-c[i]/2;
             n++;
             break;
         }
     
     return min(maxi,1+f());
 }
 
 int main(){
 
 
     freopen("in.txt","r",stdin);
     freopen("out.txt","w",stdout);
     
     int tc;
     cin>>tc;
 
     for(int caso=1;caso<=tc;caso++){
         cin>>n;
         int maxi=0;
         int aux;
         for(int i=0;i<n;i++){
             cin>>c[i];
         }
         
         
         
         cout<<"Case #"<<caso<<": "<<f()<<endl;
     }
 
     return 0;
 }
