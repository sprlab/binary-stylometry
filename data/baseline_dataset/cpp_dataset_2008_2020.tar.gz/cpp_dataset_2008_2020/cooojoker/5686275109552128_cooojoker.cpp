//#define LOCAL
 #include <iostream>
 #include <algorithm>
 #include <vector>
 #include <string>
 using namespace std;
 
 int main()
 {
 #ifdef LOCAL
 	freopen("B-small-attempt2.in", "r", stdin);
 	freopen("B-small-attempt2.out", "w", stdout);
 #endif
 	int t;
 	cin >> t;
 	for (int i = 0; i<t; i++)
 	{
 		int num;
 		cin >> num;
 		vector<int> diners;
 		for (int j = 0; j < num; j++)
 		{
 			int temp;
 			cin >> temp;
 			diners.push_back(temp);
 		}
 		make_heap(diners.begin(), diners.end());
 		int minute = diners.front();
 		int usedMinute = 0;
 		while (diners.size() != 0 && diners.front() != 1){
 			int max = diners.front();
 			int maxNum = count(diners.begin(), diners.end(), diners.front());
 			for (int j = 0; j < maxNum; j++)
 			{
 				pop_heap(diners.begin(), diners.end());
 				diners.pop_back();
 			}
 			int newMin;
 			if (diners.size() == 0)
 				newMin = usedMinute + maxNum + (max / 2 + max % 2);
 			else
 				newMin = usedMinute + maxNum + (diners.front() > (max / 2 + max % 2) ? diners.front() : (max / 2 + max % 2));
 			
 			if (newMin <= minute)
 				minute = newMin;
 			else break;
 			usedMinute += maxNum;
 			for (int j = 0; j < maxNum; j++)
 			{
 				diners.push_back(max / 2);
 				push_heap(diners.begin(), diners.end());
 				diners.push_back(max / 2 + max % 2);
 				push_heap(diners.begin(), diners.end());
 			}
 		}
 		cout << "Case #" << i + 1 << ": " << minute<< endl;
 	}
 	return 0;
 }