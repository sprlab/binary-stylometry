//#pragma comment(linker, "/STACK:16777216")
 #include <fstream>
 #include <iostream>
 #include <string>
 #include <complex>
 #include <math.h>
 #include <set>
 #include <vector>
 #include <map>
 #include <queue>
 #include <stdio.h>
 #include <stack>
 #include <algorithm>
 #include <list>
 #include <ctime>
 #include <memory.h>
 #include <ctime> 
  
 #define y0 sdkfaslhagaklsldk
 #define y1 aasdfasdfasdf
 #define yn askfhwqriuperikldjk
 #define j1 assdgsdgasghsf
 #define tm sdfjahlfasfh
 #define lr asgasgash
  
 #define eps 1e-9
 //#define M_PI 3.141592653589793
 #define bs 1000000007
 #define bsize 256
  
 using namespace std;
 
 long tests;
 long n;
 long ans;
 string st;
 long s;
 long ts;
 
 int main(){
 //freopen("k.in","r",stdin);
 //freopen("k.out","w",stdout);
 freopen("C:/input.txt","r",stdin);
 freopen("C:/output.txt","w",stdout);
 ios_base::sync_with_stdio(0);
 //cin.tie(0);
 
 cin>>tests;
 for (;tests;--tests)
 {
     ++ts;
     cin>>n;
     cin>>st;
     ans=0;
     s=0;
     for (int i=0;i<st.size();i++)
     {
         if (s<i)ans=max(ans,i-s);
         s+=st[i]-48;
     }
     cout<<"Case #"<<ts<<": "<<ans<<endl;
 }
 
 cin.get();cin.get();
 return 0;}
