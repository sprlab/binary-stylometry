#include <iostream>
 #include <iomanip>
 #include <string>
 #include <vector>
 #include <queue>
 using namespace std;
 
 double B, F, X;
 double test(double curr, double co, double ct)
 {
     double wT = X/co; //wait util reach
     double nextAddT = B/co; //wait util to buy next
     if(nextAddT+(X/(co+F))>=wT) return ct+wT;
     double chkNext = test(0, co+F, ct+nextAddT);
     if(ct+wT<chkNext) return ct+wT;
     return chkNext;
 }
 
 void main()
 {
     cout.setf(ios::fixed);
     cout.precision(7);
     //cout << 3.12345 << endl;
 
     int T;
     cin >> T;
     for(int C=0; C<T; ++C)
     {
         //double B, F, X;
         cin >> B >> F >> X;
         cout << "Case #" << C+1 << ": ";
         cout  << test(0, 2, 0) << endl;
         
     }
 
 }