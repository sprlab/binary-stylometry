#include <bits/stdc++.h>
 
 #define ll long long
 #define mp make_pair
 #define pb push_back
 #define fi first
 #define se second
 #define ld double
 
 using namespace std;
 
 const int nm = 1026;
 
 string s;
 int n;
 int d[nm];
 
 int cs(string s) {
 	int res = 0;
 	for (int i = 0; i < s.length(); ++i)
 		res = res * 2 + (s[i] == '+');
 	return res;
 }
 
 int bit(int i, int j) {
 //	cout << "bit " << i << " " << j << " " << ((i >> j) & 1) << "\n";
 	return ((i >> j) & 1);
 }
 
 int flip(int i, int j) {
 	int res = 0;
 	for (int u = 0; u < n; ++u) {
 		int x;
 		if (u <= j)
 			x = 1 - bit(i, n - 1 - j + u);
 		else
 			x = bit(i, n - 1 - u);
 //		cout << "dkm " << i << " " << j << " " << u << " " << x << "\n";
 		if (x)
 			res = (1 << (n - 1 - u)) | res;
 		else
 			res = (~(1 << (n - 1 - u))) & res;
 	}
 //	cout << "flip " << i << " " << j << " = " << res << "\n";
 	return res;
 }
 
 void solve(int test) {
 	cout << "Case #" << test << ": ";
 	cin >> s;
 	n = s.length();
 	memset(d, 0x3f, sizeof(d));
 	int st = cs(s);
 	if (st == (1 << n) - 1) {
 		cout << "0\n";
 		return;
 	}
 	d[st] = 0;
 	queue<int> q;
 	q.push(st);
 	bool found = 0;
 	while (!q.empty()) {
 		int i = q.front();
 		q.pop();
 //		cout << i << " " << d[i] << "\n";
 		for (int j = 0; j < n; ++j) {
 			int i2 = 0;
 			i2 = flip(i, j);
 			if (d[i2] > d[i] + 1) {
 				d[i2] = d[i] + 1;
 //				cout << i << " " << d[i] << " " << i2 << " " << d[i2] << "\n";
 				if (i2 == (1 << n) - 1) {
 					found = 1;
 					break;
 				}
 				q.push(i2);
 			}
 		}
 		if (found)
 			break;
 	}
 	cout << d[(1 << n) - 1] << "\n";
 }
 
 int main() {
 #ifdef LOCAL
 	freopen("B-small-attempt0.in", "r", stdin);
 	freopen("output.txt", "w", stdout);
 #endif
 	ios_base::sync_with_stdio(0);
 	cin.tie(0);
 	int t;
 	cin >> t;
 	for (int i = 1; i <= t; ++i)
 		solve(i);
 }
