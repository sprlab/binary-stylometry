#include <iostream>
 #include <cstdio>
 #include <string>
 #include <vector>
 using namespace std;
 
 struct data {
 	long long index;
 	long long last_left;
 	long long last_right;
 	long long min;
 	long long max;
 };
 
 bool compare(const data &a, const data &b)
 {
 	if (a.min > b.min) {
 		return true;
 	}
 	else if (a.min==b.min) {
 		if (a.max > b.max) {
 			return true;
 		}
 		else if (a.max == b.max) {
 			return a.index < b.index;
 		}
 		else return false;
 	}
 	else return false;
 }
 
 int main() {
 	int t;
 	scanf("%d",&t);
 
 	long long N, P;
 	for (int i=0; i<t; i++) {
 		scanf("%lld %lld",&N, &P);
 		bool arr[N+2];
 		memset (arr,false,sizeof(arr));
 		
 		arr[0] = true; //first
 		arr[N+1] = true; //last
 
 		for (int j=1; j<=P; j++) { //incoming person
 			data information[N+2];
 
 			int last_left = -1;
 			for (int k=0; k<N+2; k++) { //last left
 				if (arr[k]) {
 					last_left = k;
 					data d;
 					d.index = 999999999999999999;
 					d.last_left = -999999999999999999;
 					d.last_right = -999999999999999999;
 					d.min = -999999999999999999;
 					d.max = -999999999999999999;
 					information[k] = d;
 				}
 				else {
 					data d;
 					d.index = k;
 					d.last_left = k-last_left-1;
 					d.last_right = -1;
 					d.min = -1;
 					d.max = -1;
 					information[k] = d;
 				}
 			}
 			int right_most = -1;
 			for (int k=N+1; k>=0; k--) { //last right
 				if (arr[k]) {
 					right_most = k;
 				}
 				else {
 					information[k].last_right = right_most-k-1;
 					information[k].min = min(information[k].last_left, information[k].last_right);
 					information[k].max = max(information[k].last_left, information[k].last_right);
 				}
 			}
 
 			// for (int k=0; k<N+2; k++) {
 			// 	cout << information[k].index << " " << information[k].last_left << " " << information[k].last_right << " " << information[k].min << " " << information[k].max << endl;
 			// }
 
 
 			sort(information, information+N+2, compare);
 			// for (int k=0; k<N+2; k++) {
 			// 	cout << information[k].index << " " << information[k].last_left << " " << information[k].last_right << " " << information[k].min << " " << information[k].max << endl;
 			// }
 
 			arr[information[0].index] = true;
 			if (j==P) {
 				printf("Case #%d: %lld %lld\n",i+1, information[0].max, information[0].min);
 			}
 		}
 	}
 	return 0;
 }