#include<bits/stdc++.h>
 using namespace std;
 typedef long long int ll;
 typedef vector<int> vi;
 typedef vector<char> vc;
 typedef pair<int, int> pi;
 const int mod = 1e9 + 7;
 const double EPS = 1e-9;
 const int INF = 1 << 29;
 #define mp make_pair
 #define el putchar('\n')
 #define sp putchar(' ')
 #define Fill(a,val) memset(a,val,sizeof a)
 #define all(a) a.begin(),a.end()
 #ifndef ONLINE_JUDGE
 #define tr(a, it) for (decltype(a.begin()) it = a.begin(); it != a.end(); ++it)
 #else
 #define tr(a, it) for (typeof(a.begin()) it = a.begin(); it != a.end(); ++it)
 #endif
 #define in(n) scanf("%d",&n)
 #define inl(n) scanf("%lld",&n)
 #define out(n) printf("%d",n);
 #define outl(n) printf("%lld",n);
 
 int main(){
 	freopen("ip.in", "r", stdin);
 	freopen("op.out", "w", stdout);
 	int t; in(t);
 	for (int cs = 1; cs <= t; ++cs){
 		int n, k; in(n); in(k);
 		printf("Case #%d: ", cs);
 		map<int, int>mm;
 		set<int>s;
 		mm[n] = 1;
 		s.insert(n);
 		for (int i = 1; i < k; ++i){
 			int num = *s.rbegin();
 			--mm[num];
 			if (mm[num] == 0)s.erase(num);
 			if (num & 1){
 				int a = num >> 1;
 				if (a){
 					mm[a] += 2;
 					s.insert(a);
 				}
 			}
 			else{
 				int b = num >> 1, a = b - 1;
 				if (a > 0){
 					++mm[a]; s.insert(a);
 				}
 				if (b > 0){
 					++mm[b]; s.insert(b);
 				}
 			}
 		}
 		int num = *s.rbegin();
 		int cc = num >> 1;
 		if (num & 1){
 			out(cc); sp; out(cc); el;
 		}
 		else{
 			out(cc); sp; out(cc - 1); el;
 		}
 	}
 	return 0;
 }