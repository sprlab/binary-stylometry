#include <iostream>
 #include <cstdio>
 #include <cstring>
 #include <algorithm>
 #include <cmath>
 #include <map>
 #include <string>
 #include <set>
 #include <vector>
 #include <queue>
 #include <stack>
 #include <bitset>
 using namespace std;
 
 typedef long long LL;
 #define pb push_back
 
 bool check(int x){
 	int cur = 99;
 	while(x){
 		if(cur < x%10) return 0;
 		cur = x%10;
 		x /= 10;
 	}
 	return 1;
 }
 
 int main () {
 	int T;
 	scanf("%d", &T);
 	for(int tt = 1; tt <= T; ++tt){
 		printf("Case #%d: ", tt);
 		int x;
 		cin>> x;
 		for(int i = x; i >= 0; --i){
 			if(check(i)){
 				printf("%d\n", i);
 				break;
 			}
 		}
 	}
 }