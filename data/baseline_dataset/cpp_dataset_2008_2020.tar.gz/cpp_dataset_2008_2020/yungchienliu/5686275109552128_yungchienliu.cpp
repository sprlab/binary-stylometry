#include <cstdio>
 #include <cstring>
 #include <iostream>
 using namespace std;
 
 int a[1010]={}, map[1010], value;
 
 bool find(int p){
 	for(int i = 1000; i > p ; i--) if(map[i]){ value = i; return 1;}
 	return 0;
 }
 
 int main () {
 	freopen("in.txt", "r", stdin);
 	freopen("out.txt", "w", stdout);
 	a[1] = 1; a[2] = 1; a[3] = 1;
 	for(int i = 4; i <= 1000; i++){
 		int m = i, x = 1;
 		for(int j = 2; j*j <= i; j++){
 			if(i%j) {if( j+i/j < m) { m = j+i/j; x = j;}}
 			else if(j-1+i/j < m) {m = j-1+i/j; x = j;}
 		}
 		a[i] = x;
 	}
 	int t;
 	scanf("%d", &t);
 	for(int tt = 1; tt <= t; tt++){
 		memset(map, 0, sizeof(map));
 		int n, x;
 		scanf("%d", &n);
 		while(n--){
 			scanf("%d", &x);
 			map[x]++;
 		}
 		int M = 1001;
 		while(!map[M]) M--;
 		int f = 0, ans = 0;
 		while(find(f)){
 			ans += (a[value]-1)*map[value];
 			if(value%a[value]){
 				int s = value / a[value];
 				map[s] += (a[value]- value % a[value])*map[value];
 				map[s+1] += (value % a[value])*map[value];
 				f = s+1;
 			}
 			else {
 				map[ value / a[value] ] += a[value]*map[value];
 				f = value/a[value];
 			}
 			map[value] = 0;
 		}
 		ans += f;
 		printf("Case #%d: %d\n", tt, ans);
 	}
 }