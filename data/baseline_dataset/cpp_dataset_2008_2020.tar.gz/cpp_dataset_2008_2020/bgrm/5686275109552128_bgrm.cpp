#include <cstdio>
 
 const int maxN = 1000;
 int T[maxN + 1];
 
 int main()
 {
     int t;
     scanf ("%d", &t);
 
     for (int test=1; test<=t; test++)
     {
         int n;
         scanf ("%d", &n);
 
         for (int i=0; i<n; i++)
         {
             int a;
             scanf("%d", &a);
 
             T[a]++;
         }
 
         int res = 0;
 
         for (int i=maxN; i>0; i--)
         {
             if (T[i] == 0)
                 continue;
 
             if (T[i] <= i / 2)
             {
                 res += T[i];
                 T[i / 2] += T[i];
                 T[(i + 1) / 2] += T[i];
             }
 
             else
             {
                 res += i;
                 break;
             }
         }
 
         printf("Case #%d: %d\n", test, res);
 
         for (int i=1; i<=maxN; i++)
             T[i] = 0;
     }
 
     return 0;
 }
