#include <iostream>
 #include <cstdlib>
 #include <vector>
 #include <queue>
 #include <stack>
 using namespace std;
 
 bool trynum(int n) {
 	stack<int> S;
 	while( n > 0) {
 		S.push( n%10 );
 		n /= 10;
 	}
 
 	int p = S.top();
 	S.pop();
 	
 	bool f = true;
 	while(!S.empty()) {
 		int t = S.top();
 		S.pop();
 		
 		if(t < p) {
 			f = false;
 			break;
 		}
 		p = t;
 	}
 	return f;
 }
 
 
 int main() {
 	ios_base::sync_with_stdio(0);
 
 	int T;
 	cin>>T;
 
 	for(int tt=1; tt<=T; tt++) {
 
 		int N;
 		cin>>N;
 
 		int i;
 		for(i=N; i>=0; i--) {
 			if(trynum(i))
 				break;
 		}
 
 
 
 		cout<<"Case #"<<tt<<": "<<i<<endl;
 
 	}
 	return 0;
 }