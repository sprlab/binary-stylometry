#include <iostream>
 #include <cstdlib>
 #include <vector>
 #include <queue>
 using namespace std;
 #define MAX_SIZE 1027
 
 vector<int> V[MAX_SIZE];
 int D[MAX_SIZE];
 
 void bfs(int s, int d) {
 	D[s] = 0;
 	queue<int> Q;
 	Q.push(s);
 	while(!Q.empty()) {
 		int x = Q.front();
 		Q.pop();
 
 		for(int j=0; j<V[x].size(); j++) {
 			int y = V[x][j];
 			if(D[y] == -1) {
 				D[y] = D[x]+1;
 				Q.push(y);
 			}
 		}
 		if(D[d] != -1)
 			break;
 	}
 }
 
 void wypisz() {
 	for(int i=0; i<MAX_SIZE; i++)
 		//cout<<V[i].size()<<endl;
 		if(V[i].size() != 0) {
 			cout<<i<<":"<<endl;
 			for(int j=0; j<V[i].size(); i++) {
 				cout<<"   "<<V[i][j]<<endl;
 			}
 		}
 
 }
 
 int main() {
 	ios_base::sync_with_stdio(0);
 
 	int T;
 	cin>>T;
 
 	for(int tt=1; tt<=T; tt++) {
 		string S;
 		int K;		
 		cin>>S>>K;
 		
 		for(int i = 0; i<MAX_SIZE; i++) {
 			D[i] = -1;
 			V[i].clear();
 		}
 
 		int l = S.length();
 		int s = (1<<K) - 1;
 
 		for(int i = 0; i < (1<<l); i++) {
 			for(int j = 0; j<=l-K; j++) {
 				int back_rest = (i & ((1<<(j)) - 1));
 				int front_rest = (i >> (j + K));
 
 				int num = ((i>>j) & s);
 				int change = (num ^ s);
 
 				int edge = back_rest + (change << j) + (front_rest << (j+K));
 				V[i].push_back(edge);
 			}
 		}
 
 
 		int source = 0;
 		int p = 1;
 		for(int i = 0; i < S.length() ; i++) {
 			if(S[i] == '+')
 				source += p;
 			p *= 2;
 		}
 		int dest = (1<<l) - 1;
 
 		bfs(source, dest);
 
 		int result = D[dest];
 
 
 		cout<<"Case #"<<tt<<": ";
 		if(result != -1)
 			cout<<result;
 		else
 			cout<<"IMPOSSIBLE";
 		cout<<endl;
 
 	}
 	return 0;
 }