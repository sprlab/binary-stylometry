#include<iostream>
 using namespace std;
 
 const int inf = 2*1000*1000*1000 + 7;
 int A[10][10];
 int P[7];
 
 void prepare() {
     for(int i = 1; i<=9; i++)
     {
         for(int j = i; j<=9; j++)
         {
             A[i][j] = j/i - 1;
             if( j%i != 0)
                 A[i][j] += 1;
             A[i][j] = max(A[i][j], 0);
         }
     }
 }
 
 int main() {
     ios_base::sync_with_stdio(0);
     prepare();
     int T;
     cin>>T;
 
     for(int tt = 1; tt<=T; tt++) {
         int d, m=0, o = inf;
         cin>>d;
         for(int i = 1; i<=d; i++)
         {
             cin>>P[i];
             m=max(m, P[i]);
         }
 
         for(int i = 1; i<=m; i++) {
             int w = i;
             for(int j = 1; j<=d; j++)
             {
                 w+=A[ i ][ P[j] ];
             }
             o = min( o, w);
             //cout<<i<<" "<<w<<endl;
         }
 
         cout<<"Case #"<<tt<<": "<<o<<endl;
     }
     return 0;
 }
