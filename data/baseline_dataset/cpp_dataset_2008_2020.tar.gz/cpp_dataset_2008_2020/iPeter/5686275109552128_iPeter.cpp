#include <cstdio>
 #include <cstring>
 #include <algorithm>
 using namespace std;
 
 int s[2000],ans;
 void dfs(int a, int b){
 	if(b>=ans) return;
 	if(a==0){
 		ans=min(ans,b);
 		return;
 	}
 	if(s[a]==0){
 		dfs(a-1,b);
 		return;
 	}
 	
 	int q[20];
 	for(int i=1;i<=a;i++)
 		q[i]=s[i];
 	
 	for(int i=0;i<a;i++)
 		s[i]=s[i+1];
 	dfs(a-1,b+1);
 	for(int i=1;i<=a;i++)
 		s[i]=q[i];
 
 	if(a>1){
 		s[a]--;
 		s[a/2]++;
 		s[(a+1)/2]++;
 		dfs(a,b+1);
 		for(int i=1;i<=a;i++)
 			s[i]=q[i];
 	}
 	if(a>2){
 		s[a]--;
 		s[a/3]++;
 		s[a/3+(a%3==1)]++;
 		s[a/3+(a%3==2)]++;
 		dfs(a,b+2);
 		for(int i=1;i<=a;i++)
 			s[i]=q[i];
 	}
 }
 int main(void){
     int t;
     scanf("%d",&t);
     for(int tt=1;tt<=t;tt++){
 		int n,a=0;
 		scanf("%d", &n);
 		memset(s,0,sizeof(s));
 		for(int i=0;i<n;i++){
 			int x;
 			scanf("%d",&x);
 			s[x]++;
 		}
 		
 		ans = 1000;
 		dfs(10,0);
 		
 		// for(int i=1000;i>0;i--){
 		// 	if(s[i]==0) continue;
 		// 	ans = min(a+i, ans);
 		// 	a += s[i];
 		// 	s[i/2]+=s[i];
 		// 	s[(i+1)/2]+=s[i];
 		// }
         
         printf("Case #%d: %d\n", tt, ans);
     }
     return 0;
 }
 
