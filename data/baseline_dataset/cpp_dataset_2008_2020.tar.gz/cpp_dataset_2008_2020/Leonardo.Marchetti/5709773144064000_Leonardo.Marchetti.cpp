#include<cstdio>
 
 double C, F, X;
 
 double tenta(int f, double g) {
 	if(f ==0)
 		return X/g;
 	return C/g + tenta(f-1, g + F); 
 }
 
 
 int main(){
 	int t;
 	scanf("%d", &t);
 	for(int c = 1; c<=t; c++) {
 		scanf("%lf %lf %lf", &C, &F, &X);
 		double ret;
 		for(int i=0;; i++) {
 			double r = tenta(i, 2.0);
 			if (i && r > ret) break; 			
 			ret = r;
 		}
 		printf("Case #%d: %.7f\n", c, ret); 
 	}
 	return 0;
 }
