#include<iostream>
 #include<vector>
 using namespace std;
 
 int main() {
   int t;
   cin >> t;
   for(int c=1;c<=t;++c) {
     int n, k;
     cin >> n >> k;
     vector<int> v;
     v.push_back(n);
     int r1=0, r2=0;
     while(k--) {
       auto mp = max_element(v.begin(), v.end());
       int m = *mp - 1;
       r1 = (m+1)/2;
       r2 = m/2;
       mp = v.erase(mp);
       mp = v.insert(mp, r1);
       mp = v.insert(mp, r2);
     }
     cout << "Case #" << c << ": " << r1 << " " << r2 << endl;
   }
   return 0;
 }
