#include<iostream>
 #include<queue>
 #include<algorithm>
 using namespace std;
 
 int t, d, p;
 
 
 int main() {
 	cin.sync_with_stdio(false);
 	
 	cin >> t;
 	
 	for(int TCASE = 1; TCASE <= t; TCASE++) {
 		cin >> d;
 		
 		priority_queue<int> plate;
 		
 		for(int i=0;i<d;i++)
 			cin >> p, plate.push(p);
 		
 		int result = 1000000000;
 		
 		for(int i=0;i<result;i++) {
 			int topplate = plate.top();
 			plate.pop();
 			
 			result = min(result, topplate + i);
 			
 			plate.push(topplate / 2);
 			plate.push(topplate - topplate / 2);
 		}
 		
 		cout << "Case #" << TCASE << ": " << result << '\n';
 		
 	}
 	
 	
 	return 0;
 }
