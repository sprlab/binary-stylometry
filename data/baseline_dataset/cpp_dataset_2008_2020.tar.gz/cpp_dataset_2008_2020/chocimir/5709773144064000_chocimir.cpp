#include<algorithm>
 #include<cassert>
 #include<cctype>
 #include<cmath>
 #include<cstdio>
 #include<cstdlib>
 #include<cstring>
 #include<deque>
 #include<iostream>
 #include<list>
 #include<map>
 #include<queue>
 #include<set>
 #include<string>
 #include<vector>
 using namespace std;
 
 typedef long long LL;
 typedef long double LD;
 
 #define dprintf(...) fprintf(stderr, __VA_ARGS__)
 
 int cond = 1;
 #define DB(X) {if(cond){cerr<<"Line:"<<__LINE__<<", "<<#X<<" = "<<X<<endl;}}
 double getnb(long double r, long double c, long double x, long double f) {
 	return c/r + x/(r+f);
 }
 int main() {
 	int t; cin >> t;
 	for(int xx = 1; xx <= t; ++xx){
 		long double c, f, x; cin >> c >> f >> x;
 		long double r = 2.;
 		double time = 0., bc, nb;
 		while(true) {	
 			bc = getnb(r, c, x, f);
 			nb = x/r;
 			if (bc < nb) {
 				time += c/r;
 			}
 			else {
 				time += x/r;
 				break;
 			}
 			r += f;
 		}
 		cout << "Case #" << xx << ": " << time << endl;//result 
 	}
 	return 0;
 }
 
 
