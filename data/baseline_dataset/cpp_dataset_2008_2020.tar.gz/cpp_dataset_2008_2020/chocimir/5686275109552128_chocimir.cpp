#include<algorithm>
 #include<cassert>
 #include<cctype>
 #include<cmath>
 #include<cstdio>
 #include<cstdlib>
 #include<cstring>
 #include<deque>
 #include<iostream>
 #include<list>
 #include<map>
 #include<queue>
 #include<set>
 #include<string>
 #include<vector>
 using namespace std;
 
 typedef long long LL;
 typedef long double LD;
 
 #define dprintf(...) fprintf(stderr, __VA_ARGS__)
 
 int cond = 1;
 #define DB(X) {if(cond){cerr<<"Line:"<<__LINE__<<", "<<#X<<" = "<<X<<endl;}}
 int tab[10000];
 int n;
 int count(int a, int b) {
 	return (upper_bound(tab, tab + n, b) - lower_bound(tab, tab + n, a));
 }	
 int main() {
 	int t; cin >> t;
 	for(int x = 1; x <= t; ++x){
 		cin >> n;
 		for(int i = 0; i < 1002; ++i) {
 			tab[i] = 0;
 		}
 		int m = 0;
 		for(int i = 0; i < n; ++i) {
 			int k; cin >> k;
 			tab[k]++;
 			if (k > m) m = k;
 		}
 
 		int m2 = m - 1;
 		while (m2 >= 0 && tab[m2] == 0) {
 			m2--;
 		}
 		int res_best = m;
 		int prev = 0;
 		while ((m + 1) / 2 > tab[m]) {
 			tab[m/2]++;
 			tab[(m + 1) / 2]++;
 			tab[m]--;
 			while (!tab[m]) m--;
 			prev += 1;
 			res_best = min(res_best, m + prev);
 		}
 		cout << "Case #" << x << ": " << res_best<< "\n";//result 
 	}
 	return 0;
 }
 
