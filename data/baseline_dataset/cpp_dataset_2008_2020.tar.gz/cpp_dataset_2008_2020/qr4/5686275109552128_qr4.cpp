#include<iostream>
 #include <algorithm>
 #include <vector>
 #include<string>
 
 
 using namespace std;
 
 int main()
 {
   int T;
   cin >> T;
   for (int i = 0; i < T; i++)
   {
     int D;
     cin >> D;
 
     std::vector<int> plates;
     for (int j = 0; j < D; j++)
     {
       int temp;
       cin >> temp;
       plates.push_back(temp);
     }
 
     int result = 0;
 
     for (;;result++)
     {
       sort(plates.begin(), plates.end(), greater<int>());
 
       if (plates.at(0) == 0) break;
 
       if ((plates.at(0) % 2) == 0 && plates.at(0) > 2)
       {
         plates.push_back(plates.at(0) / 2);
         plates.at(0) /= 2;
       } else {
         for (auto& pl : plates)
         {
           pl--;
         }
       }
     }
     cout << "Case #" << i+1 << ": " << result << endl;
   }
 }
