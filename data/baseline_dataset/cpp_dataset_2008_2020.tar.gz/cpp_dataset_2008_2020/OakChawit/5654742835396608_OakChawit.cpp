#include <bits/stdc++.h>
 
 #define pii pair<int, int>
 #define pll pair<LL, LL>
 #define F first
 #define S second
 #define B begin()
 #define E end()
 #define MOD 1000000007
 #define itt iterator
 #define ritt reverse_iterator
 #define LL long long
 
 #define PI (4 * atan(1))
 
 using namespace std;
 
 typedef struct compare{
 	bool operator ()(pll x, pll y)
 	{
 		if(x.S - x.F < y.S - y.F)
 			return true;
 		if(x.S - x.F == y.S - y.F && x.F > y.F)
 			return true;
 		return false;
 	}
 }Compare;
 
 int t;
 LL n, k, m;
 priority_queue<pll, vector<pll>, Compare> mq;
 pll cur;
 
 int main()
 {
 	// freopen("C-small-1-attempt0.in", "r", stdin);
 	// freopen("C-small-1-attempt0.out", "w", stdout);
 
     scanf("%d", &t);
     for(int z = 1; z <= t; ++z)
 	{
 		while(!mq.empty())
 			mq.pop();
 
 		scanf("%lld %lld", &n, &k);
 		mq.push(pll(1LL, n));
 		for(int i = 0; i < k - 1; ++i)
 		{
 			cur = mq.top();
 			mq.pop();
 			m = (cur.F + cur.S) / 2;
 			if(m - 1 >= cur.F)
 				mq.push(pll(cur.F, m - 1));
 			if(cur.S >= m + 1)
 				mq.push(pll(m + 1, cur.S));
 		}
 		cur = mq.top();
 		m = (cur.F + cur.S) / 2;
 		printf("Case #%d: %lld %lld\n", z, max(cur.S - m, m - cur.F), min(cur.S - m, m - cur.F));
 	}
     return 0;
 }