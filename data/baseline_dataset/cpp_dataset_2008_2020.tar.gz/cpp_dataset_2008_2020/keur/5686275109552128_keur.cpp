#include <iostream>
 #include <queue>
 #include <map>
 using namespace std;
 
 priority_queue<int> B;
 map<int,int> C;
 constexpr int min (int a, int b){ return (a < b ? a : b) ;}
 int getint(void){int m; cin >>m; return m; }
 
 int min_(void){ return ( not B.empty() ? B.top() : 0);}
 
 int answer(void){
 	B = priority_queue<int> ();
 	const int D = getint();
 	for (int q = 0; q < D; ++q)	B.push(getint()); 
 	int l = 0;
 	int M = B.top();
 	while  (min_() > 1){
 		const int n = B.top();
 		B.pop(); B.push(n/2); B.push((n+1)/2);
 		++l; M = min(M,l+min_());
 	}
 	return M;
 }
 int answer2(void){
 	vector<int> C (1001,0);
 	const int D = getint();
 	int M= 5000;
 	for (int q = 0; q < D; ++q)	C[getint()]++;
 	int l = 0;
 
 	for (int q = 1000; q >= 0; --q) {
 		if (C[q] != 0) {
 			M = min(M,l+q);
 			l += C[q];
 			if (q/2 != 0) C[q/2] += C[q];
 			if ((q+1)/2 != 0)C[(q+1)/2] += C[q];
 			}
 	}
 	return M;
 }
 
 
 int main(void){
 	const int t = getint();
 	for (int q = 0; q < t; ++q) printf("Case #%i: %i\n", q+1, answer2());
 }
