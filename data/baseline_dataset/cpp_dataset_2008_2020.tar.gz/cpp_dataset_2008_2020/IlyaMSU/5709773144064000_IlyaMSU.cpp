#define _CRT_SECURE_NO_WARNINGS
 #pragma comment(linker, "/STACK:256000000")
 #define _USE_MATH_DEFINES
 #include<iostream>
 #include<vector>
 #include<string>
 #include<stack>
 #include<algorithm>
 #include<cmath>
 #include<set>
 #include<queue>
 #include<sstream>
 #include<utility>
 #include<map>
 #include<ctime>
 #include<cstdio>
 
  
 using namespace std; 
  
 typedef long long ll; 
 typedef unsigned int uint; 
 typedef unsigned long long ull; 
 typedef pair<ll, ll> pll;
 typedef pair<int, int> pii;
 typedef pair<char, char> pcc;
 typedef pair<double, double> pdd;
 
 #define show(x) cerr << x
 #define debug(x) show(#x << ": " << (x) << endl)
 
 const long double PI = 3.14159265358979323846;  
 const long double gammama = 0.57721566490153286060;
 const long double eps = 1e-7;
 const int INF = 1000 * 1000 * 1000 + 1;
 const ll LINF = (ll)1000 * 1000 * 1000 * 1000 * 1000 * 1000;
 
 
 long double solve() {
 	long double c, f, x;
 	cin >> c >> f >> x;
 	long double r = 2;
 	if (c > x) 
 		return 1.0 * x / 2;
 	long double t = 0;
 	while(c * r < (x - c) * f) {
 		t += 1.0 * c / r;
 		r += f;		
 	}
 	t += 1.0 * x / r;
 	return t;
 }
 
 int main() {
 	freopen("input.txt", "r", stdin);
 	freopen("output.txt", "w", stdout);
 	int t;
 	cin >> t;
 	for (int i = 0; i < t; ++i) {
 		cout << "Case #" << i + 1 << ": ";
 		printf("%0.18f\n", solve());
 		std::cerr << i << endl;
 	}
 	return 0;
 }
